package apriorialgorithm.core;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/*This Java file is used to store the item names contained in the
- transactions. For each item, a number is assigned, so that itemset only
- contains integers.*/

public class Lables {

	private Map<String, Integer> NameInt;
	private Map<Integer, String> Namei;
	private int lAvailableProductId = 0;

	private Lables() {
		NameInt = new HashMap<>();
		Namei = new HashMap<>();
	}

	
	static private Lables i;

	static public Lables getInstance() {
		if (i == null) {
			i = new Lables();
		}
		return i;
	}

	//returns the name of the product 
	//null if it's not found
	
	public String nameCorrespondence(Integer i) {
		return ( Namei.containsKey(i) ) ? Namei.get(i) : null;
	}
	
	// Returns the all the products list.
		public List<Integer> getAllProducts() {
			List<Integer> list = new ArrayList<>();
			for (String s : NameInt.keySet()) {
				list.add(NameInt.get(s));
			}
			return list;
		}

	
	public int addNameCorrespondance(String s) {
		if (NameInt.containsKey(s)) {
			return NameInt.get(s);
		}

		int res = lAvailableProductId;
		NameInt.put(s, lAvailableProductId);
		Namei.put(lAvailableProductId, s);
		++lAvailableProductId;
		return res;
	}

	

	// Reinitiates the Labels.
		public void clear() {
		NameInt.clear();
		Namei.clear();
		lAvailableProductId = 0;
	}
}
