package apriorialgorithm.core;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;


public class ItemSets extends HashSet<Integer> {

	private static final long serialVersionUID = 6460184394001610729L;

	public ItemSets(ItemSets is12) {
		super(is12);
	}

	public ItemSets() {
		super();
	}
	
	//Returns the absolute support of the item sets.

	
	public int getSupport() {
		return Support.get(this);
	}

	// Support contains value of absolute support. 
	//Support is used in some parts of code.
	
	public int getRelativeSupport() {
		return Support.getRelative(this);
	}
	
	
	/*
	 -Generates all the possible rules for an item set given. This is used for
	 - generating the rules once the frequent item sets have been computed.
	  
	 - This also uses the one-to-one generation function of subsets (@see
	 - subsetWithoutOneElement()). Here, if the i-th bit of the bitstring
	 - representing k is 1, we add the element to the first part of the rule
	 - (the premise); if it's 0, we add the element to the second part of the
	 - rule.
	  
	 - @return A list containing all the possible rules.
	 */
	
		public List<Associationrules> GenerateR() {
		List<Associationrules> rules = new ArrayList<>();
		List<Integer> list12 = new ArrayList<>(this);
		int size = this.size();
		for (int i = 1, limit = (int) Math.pow(2, size) - 1; i < limit; ++i) {
			ItemSets premisse = new ItemSets();
			ItemSets conclusion = new ItemSets();
			for (int j = 0; j < size; ++j) {
				if (((i >> j) & 1) == 1) {
					premisse.add(list12.get(j));
				} else {
					conclusion.add(list12.get(j));
				}
			}
			rules.add(new Associationrules(premisse, conclusion));
		}
		return rules;
	}
	
	
	/*
	 - If the itemset is of size N, generates all the (N-1)-subsets of the
	 - current itemset. It's used in the generation of the itemset from one
	 - level to another.
	  
	 - This function uses the one-to-one between subsets and integers for
	 - generating the subsets. Indeed, for each int k between 0 and 2^n,
	 - representing k as a bitstring makes it possible to generate a subset: the
	 - i-th element of the set is added to the subset if the i-th bit in k is 1,
	 - otherwise it's not added.
	  
	 - @return A list containing all the (N-1) subsets of the itemset.
	 */
	
	public List<ItemSets> subsetWithoutOneEle() {
		List<ItemSets> list = new ArrayList<>();
		List<Integer> itemsetAsArray = new ArrayList<>(this);
		int size = itemsetAsArray.size(); // this is N
		int limit = (int) Math.pow(2, size) - 1; // 2^N - 1
		//Generates all itemsets and adds only the ones which size is N-1
		for (int i = 0; i < limit; ++i) {
			ItemSets subset = new ItemSets();
			for (int j = 0; j < size; ++j) {
				if (((i >> j) & 1) == 1) {
					subset.add(itemsetAsArray.get(j));
				}
			}
		//The item sets returned should have the current size minus 1.
			if (!subset.isEmpty() && subset.size() == size - 1) {
				list.add(subset);
			}
		}
		return list;
	}

	
	

	@Override
	//Represents the itemset as a string, by retrieving the real names of the items.
	public String toString() {
		String result = "";
		int count = 0;
		for (Integer i : this) {
			if (count++ != 0) {
				result = result.concat(", ");
			}
			result = result.concat(Lables.getInstance()
					.nameCorrespondence(i));
		}
		return result;
	}
}
