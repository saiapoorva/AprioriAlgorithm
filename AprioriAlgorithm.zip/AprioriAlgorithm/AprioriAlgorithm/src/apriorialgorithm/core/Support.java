package apriorialgorithm.core;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import apriorialgorithm.core.ItemSets;


/*1. Computes and contains all the values of supports for all the
     given itemsets.
  2. The values of supports are memoized into a map. Recomputation is then avoided
  	 by looking up if the support has already been computed, which makes the
     algorithm faster.*/

public class Support {
	
	private static Map<ItemSets, Integer> map = new HashMap<>();

	// List of Transactions.
	
	private static List<ItemSets> tran = null;

		public static void setup(List<ItemSets> _transactions) {
		clear();
		tran = _transactions;
	}
		
	/*
	 - Tries to find the support of the itemset if it hasn't been computed previously, 
	   and computes it otherwise.
	 - @param itemset The itemset for which we want the support
	 - @return The support of the itemset, in number of transactions.
	*/
		
		public static int get(ItemSets item) {
		if (!map.containsKey(item)) {
			int support = 0;
			for (ItemSets it : tran) {
				if (it.containsAll(item)) {
					++support;
				}
			}
			map.put(item, support);
			return support;
		}
		return map.get(item);
	}

	// Returns the relative support of an itemset.
		
	public static int getRelative(ItemSets itemset1) {
		return 100 * get(itemset1) / tran.size();
	}
	
	/*
	 - Returns true if the itemset has already been considered. The Apriori
	 - Algorithm can sometimes generate several times the same itemset, and this
	 - function allows to avoid that.*/

		public static boolean alreadyProcessed(ItemSets items) {
		return map.containsKey(items);
	}

	// Reinitiates the Support.
		
	public static void clear() {
		map.clear();
	}
}
