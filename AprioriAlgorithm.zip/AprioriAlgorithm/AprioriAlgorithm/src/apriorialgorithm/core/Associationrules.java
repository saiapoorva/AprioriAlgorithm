package apriorialgorithm.core;


public class Associationrules {

	protected ItemSets Premise;
	protected ItemSets Conclusion;

	protected double Confidence;
	protected int Support;
	protected int RelativeSupport;
	
	//Computes Association Rules
	
	public Associationrules(ItemSets Premise, ItemSets Conclusion) {
		this.Premise = Premise;
		this.Conclusion = Conclusion;

		// compute Confidence
		ItemSets union = (ItemSets) Premise.clone();
		union.addAll(Conclusion);
		Support = union.getSupport();
		RelativeSupport = union.getRelativeSupport();
		Confidence = 100 * ((double) Support) / Premise.getSupport();
	}

	// Accessors
	
	
	public ItemSets getConclusion() {
		return Conclusion;
	}

	public double getConfidence() {
		return Confidence;
	}
	
	public ItemSets getPremise() {
		return Premise;
	}


	public int getSupport() {
		return Support;
	}

	
	public double Confidence() {
		return Confidence;
	}

	
	public int getRelativeSupport() {
		return RelativeSupport;
	}

	//converts to String.
	public String toString() {
		return Premise
				.toString()
				.concat(" => ")
				.concat(Conclusion.toString())
				.concat(" (Support: " + Support + " / Confidence: "
						+ Confidence + ")");
	}
}
