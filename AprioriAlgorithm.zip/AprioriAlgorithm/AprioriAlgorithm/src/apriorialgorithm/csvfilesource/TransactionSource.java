package apriorialgorithm.csvfilesource;

import java.util.List;

import apriorialgorithm.core.ItemSets;



public interface TransactionSource {
	
	// Returns item sets Lists.
	
	List<ItemSets> generate();
}