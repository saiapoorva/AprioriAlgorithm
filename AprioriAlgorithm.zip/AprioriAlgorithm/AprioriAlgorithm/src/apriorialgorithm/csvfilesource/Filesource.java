package apriorialgorithm.csvfilesource;

import java.util.ArrayList;

import java.util.List;

import apriorialgorithm.core.ItemSets;
import apriorialgorithm.core.Lables;



public abstract class Filesource implements TransactionSource {

	protected List<Integer> AllItems = new ArrayList<>();

	protected List<ItemSets> fromCsvStrings(List<String> items12) {
		List<ItemSets> trans = new ArrayList<>();
		for (String s : items12) {
			ItemSets transset = new ItemSets();
			for (String e : s.split(",")) {
				int corres = Lables.getInstance()
						.addNameCorrespondance(e);
				transset.add(corres);
			}
			trans.add(transset);
		}
		return trans;
	}
}
