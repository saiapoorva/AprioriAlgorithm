package apriorialgorithm.csvfilesource;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import apriorialgorithm.core.ItemSets;


public class File5 extends Filesource {
	
	
	static String Filename2="C:/Users/st583/Jcpenny.csv";
	
	
	

	public static void File53 () throws SQLException {
	
		
		
			
		
		
		 
	      String driverName = "oracle.jdbc.driver.OracleDriver";
	      String connectURL = "jdbc:oracle:thin:@prophet.njit.edu:1521:course";
	      
	      
	      
	      
	      String USER = "st583";
	        String PASS = "	ahB3ChFL6";
	        Connection conn = DriverManager.getConnection(connectURL, USER, PASS); 
	      
	      try {
	         Class.forName(driverName);
	         conn = DriverManager.getConnection(connectURL);
	      } catch (ClassNotFoundException e) {
	         System.out.println("Error creating class: "+e.getMessage());
	      } catch (SQLException e) {
	         System.out.println("Error creating connection: "+e.getMessage());
	      }
	   
	    
	         
	         try {
		         
		         
	        	 //Execute the query to populate the ResultSet
		         PreparedStatement statement2 = conn.prepareStatement("select * from JCPENNY");
		        
		         ResultSet resultset2 = statement2.executeQuery();
		         
		         //Get the ResultSet information
		         ResultSetMetaData resultmetadata2 = resultset2.getMetaData();
		         
		         //Determine the number of columns in the ResultSet
		         int numCols2 = resultmetadata2.getColumnCount();
         
		         
		     	PrintWriter f2 = new PrintWriter(new FileWriter(Filename2));
		     	
		      				 
				 //Check for data by moving the cursor to the first record (if there is one)
		         while (resultset2.next()) {
		        	 
		        	 
		            for (int j=1; j <= numCols2; j++) {		            	
		            	
		            	//For each column index, determine the column name 
		               String colName2 = resultmetadata2.getColumnName(j);
		               
		               //Get the column value
		               String colVal2 = resultset2.getString(j);
		               
		               f2.write(colVal2+"\n");
		               
		                    
					   //Determine if the last column accessed was null
		               if (resultset2.wasNull()) {
		                  colVal2 = "and up";
		               }
		               
		               
		                   
		            }
		            
		            
		         }
		         //closing the printwriter
		         f2.close();
	         }catch (SQLException | IOException e) {
		         System.out.println("SQL Error: "+e.getMessage());
		      } finally {
		         System.out.println("Closing connections...");
		         try {
		            conn.close();
		         } catch (SQLException e) {
		            System.out.println("Can't close connection.");
		         }
			  }
	}
	         
	         
	 	public List<ItemSets> generate() {
 		List<String> sources1 = new ArrayList<>();
 		try {
 			Scanner scan1 = new Scanner(new File(Filename2));
 			while (scan1.hasNextLine()) {
 				sources1.add(scan1.nextLine());
 				
 			
 			}
 			scan1.close();
 		} catch (FileNotFoundException e) {
 			e.printStackTrace();
 		}
 		
 		return fromCsvStrings(sources1);
 	}
	
}

		    
		    
	
	

	

